package com.example.playpal;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {

    Context context;
    private ItemClickListner itemClickListner;

    ArrayList<PlayActivity> list;
    StorageReference storageReference;



    public MyAdapter(Context context, ArrayList<PlayActivity> list,ItemClickListner itemClickListner) {
        this.context = context;
        this.list = list;
        this.itemClickListner = itemClickListner;
        storageReference = FirebaseStorage.getInstance().getReference();
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item,parent,false);
        return  new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        PlayActivity playActivity = list.get(position);
        holder.fullName.setText(playActivity.getOwner().getFullName());
        holder.sports.setText(playActivity.getSport());
        holder.date.setText(playActivity.getDate());
        holder.time1.setText(playActivity.getTime());
        StorageReference profileRef = storageReference.child(playActivity.getOwner().getuID()+".jpg");
        profileRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {
                Picasso.get().load(uri).into(holder.img);
            }
        });
        /*RecyclerView recyclerView = findViewById(R.id.recycler);
        recyclerView.addOnItemTouchListener(
                new RecyclerItemClickListener(context, recyclerView ,new RecyclerItemClickListener.OnItemClickListener() {
                    @Override public void onItemClick(View view, int position) {
                        // do whatever
                    }

                    @Override public void onLongItemClick(View view, int position) {
                        // do whatever
                    }
                })
        );*/





        holder.itemView.setOnClickListener(view -> {
            itemClickListner.onItemClick(list.get(position));
        });


    }


    public interface ItemClickListner{
        void onItemClick(PlayActivity playActivity);
    }



    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{

        TextView fullName,sports,date,time1;
        ImageView img;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            fullName = itemView.findViewById(R.id.fullName);
            sports = itemView.findViewById(R.id.sports);
            date = itemView.findViewById(R.id.date);
            time1 = itemView.findViewById(R.id.time1);
            img = itemView.findViewById(R.id.img);
        }




    }


}
